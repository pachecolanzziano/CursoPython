# CursoPython
curso píldoras informáticas, guiadas por la documentación oficial
