from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0", 
    description="paquete de calculos matematicos basicos",
    author="Lucas Lanzziano",
    author_email="micorreo@gmail.com",
    packages=["calculos"]
)